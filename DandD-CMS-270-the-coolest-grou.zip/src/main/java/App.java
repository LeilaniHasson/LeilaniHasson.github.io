import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

// Constants declaration should be outside the main method at the class level

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

// Constants declaration should be outside the main method at the class level
public class App {
  private static final String ANSI_RESET = "\u001B[0m";
  private static final String ANSI_RED = "\u001B[31m";
  private static final String ANSI_GREEN = "\u001B[32m";
  private static final String ANSI_YELLOW = "\u001B[33m";
  private static final String ANSI_BLUE = "\u001B[34m";
  private static final String ANSI_PURPLE = "\u001B[35m";
  private static final String ANSI_CYAN = "\u001B[36m";

  public static void main(String[] args) throws IOException {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    
    String asciiArt = ANSI_RED + " _       __     __                        \n" +
        "    | |     / /__  / /________  ____ ___  ___ \n" +
        "    | | /| / / _ \\/ / ___/ __ \\/ __ `__ \\/ _ \\\n" +
        "    | |/ |/ /  __/ / /__/ /_/ / / / / / /  __/\n" +
        "    |__/|__/\\___/\\_/\\___/\\____/_/ /_/ /_/\\___/ ";
    
    System.out.println(asciiArt);
    System.out.println(ANSI_GREEN + "\nWelcome to Dungeons & Dragons!" + ANSI_RESET);

    displayLoadingBar();

    System.out.println(ANSI_YELLOW + "Press Enter to start the game..." + ANSI_RESET);



    
    reader.readLine();
  
}

  private static void displayLoadingBar() {
      int totalSteps = 50; // Total number of steps in the loading bar
      int step = 0;
      int progress;

      while (step < totalSteps) {
          progress = (int) ((double) step / totalSteps * 100);
          System.out.print("\rLoading [");

          int progressBarLength = 20; // Length of the progress bar
          int filledLength = (int) ((double) progress / 100 * progressBarLength);
          for (int i = 0; i < progressBarLength; i++) {
              if (i < filledLength) {
                  System.out.print(ANSI_GREEN + "#" + ANSI_RESET);
              } else {
                  System.out.print(" ");
              }
          }

          System.out.print("] " + progress + "%");

          try {
              Thread.sleep(50); // Adjust the delay between each step (in milliseconds)
          } catch (InterruptedException e) {
              e.printStackTrace();
          }

          step++;
      }

      System.out.println("\nGame loaded!");
  }

}