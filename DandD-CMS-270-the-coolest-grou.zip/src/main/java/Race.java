public abstract class Race implements hasAttacks {
  private int maxHp;
  private int currentHp;
  private int constitution;
  private String title;

  public Race(int h, int c) {
    maxHp = h;
    constitution = c;
  }

  public int getMaxHp() {
    return maxHp;
  }

  public int getCurrentHp() {
    return currentHp;
  }

  public int getConstitution() {
    return constitution;
  }

  public String getTitle() {
    return title;
  }

  public void setMaxHp(int h) {
    maxHp = h;
  }

  public void setCurrentHp(int h) {
    currentHp = h;
  }

  public void setConstitution(int c) {
    constitution = c;
  }

  public void setTitle(String t) {
    title = t;
  }
}