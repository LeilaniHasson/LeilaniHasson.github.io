import java.util.Random;

public class Tiefling extends Race {

  Random r = new Random();

  // constructor
  public Tiefling(Random r) {
    //hp 6-8, constitution 10-12
    super(r.nextInt(2) + 6, 12 - r.nextInt(2));
    this.setTitle("Tiefling");
  }

  //methods
  public void attack1(Character attacker, Character opponent) {
    System.out.println("You attack " + opponent.getName() + " using a flaming sword");

    // roll 1-20 + constitution bonus
    int attack = (r.nextInt(19) + 1) + (attacker.getRace().getConstitution());
      //maxDamage: 5, attack, random, isMelee: true, distance
    opponent.beAttacked(5, attack, r, true, Main.getDistance(attacker.getPosition(), opponent.getPosition()));

  }

  public void attack2(Character attacker, Character opponent) {
    System.out.println("You channel your demonic ancestory to attack " + opponent.getName());

    // roll 1-15 + constitution bonus
    int attack = (r.nextInt(14) + 1) + (attacker.getRace().getConstitution());
      //maxDamage: 8, attack, random, isMelee: false, distance
    opponent.beAttacked(8, attack, r, false, Main.getDistance(attacker.getPosition(), opponent.getPosition()));
  }
}

/*

  private int constitutionBonous;
  private int strengthDeduction;

  // construcotr
  public Tiefling(String n, FighterType ft, int p)
  {
    super(n, ft, p);
    try{
      Random r = new Random();
        constitutionBonous = r.nextInt(4);
        strengthDeduction = r.nextInt(4);
    }
    catch (Exception e){

    }

    //get wisdom from Character
    setWisdom(getWisdom() + constitutionBonous);
    setConstitution(getConstitution() - strengthDeduction);
 */