public abstract class FighterType implements hasAttacks {
  private int wisdom;
  private int strength;
  private String title;

  public FighterType(int w, int s) {
    wisdom = w;
    strength = s;
  }

  public int getWisdom() {
    return wisdom;
  }  

  public int getStrength() {
    return strength;
  }

  public String getTitle() {
    return title;
  }

  public void setWisdom(int w) {
    wisdom = w;
  }

  public void setStrength(int s) {
    strength = s;
  }

  public void setTitle(String t) {
    title = t;
  }
}