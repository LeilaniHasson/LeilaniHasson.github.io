// cd src/main/java
// javac Main.java
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Random;


public class Main 
{

  private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_BLUE = "\u001B[34m";
    private static final String ANSI_PURPLE = "\u001B[35m";
    private static final String ANSI_CYAN = "\u001B[36m";

  public static void loadScreen()
  {
    // ----------------
    // INTRO TO PREMISE
    // ----------------
    // EXPLAIN HOW STATS WORK (race & notClass)
    System.out.println("---------------");
    System.out.println("CLASSES: \n Barbarian:  +con \n Wizard:  +wis \n Ranger:  +str");
    System.out.println("---------------");
    System.out.println("RACES: \n Goblin:  +str / -wis \n Elf:  +wis / -con \n Teifling:  +con / -str");
    System.out.println("--------------- \n");
  }

  public static void welcomeScreen() {
      System.out.println("------------------------------------------------------------");
      System.out.println(" _       __     __                        ");
      System.out.println("| |     / /__  / /________  ____ ___  ___ ");
      System.out.println("| | /| / / _ \\/ / ___/ __ \\/ __ `__ \\/ _ \\");
      System.out.println("| |/ |/ /  __/ / /__/ /_/ / / / / / /  __/");
      System.out.println("|__/|__/\\___/\\_/\\___/\\____/_/ /_/ /_/\\___/ ");
      System.out.println("\nWelcome to Dungeons & Dragons!");

      displayLoadingBar();
  }

  public static void displayLoadingBar() {
      int totalSteps = 50; // Total number of steps in the loading bar
          int step = 0;
          int progress;

          while (step < totalSteps) {
              progress = (int) ((double) step / totalSteps * 100);
              System.out.print("\rLoading [");

              int progressBarLength = 20; // Length of the progress bar
              int filledLength = (int) ((double) progress / 100 * progressBarLength);
              for (int i = 0; i < progressBarLength; i++) {
                  if (i < filledLength) {
                      System.out.print(ANSI_GREEN + "#" + ANSI_RESET);
                  } else {
                      System.out.print(" ");
                  }
              }

              System.out.print("] " + progress + "%");

              try {
                  Thread.sleep(50); // Adjust the delay between each step (in milliseconds)
              } catch (InterruptedException e) {
                  e.printStackTrace();
              }

              step++;
          }

          System.out.println("\nGame loaded!");
      }



  public static Character characterSetup(Scanner s, Random r)
  {
    String[] classes = {"Paladin", "Ranger", "Wizard"};
    String[] races = {"Elf", "Goblin", "Tiefling"};

    //get name
    int i = 0;
    String name;
    do {
      if (i > 0) {
        System.out.println("Please enter a valid name.");
      }
      System.out.println("Enter your character's name: ");
      name = s.nextLine();
      i++;
    }
    while (name == null || name == "");
    Character c = new Character(name);
    System.out.println();

    //get class
    int choice = getChoice("What class would you like to play?", classes, s);
    switch (choice) {
    case 1:
      c.setFighterType(new Paladin(r));
      break;
    case 2:
      c.setFighterType(new Ranger(r));
      break;
    case 3:
      c.setFighterType(new Wizard(r));
      break;
    default:
      System.out.println("An error has occured.");
      break;
    }
    System.out.println();

    //get race
    choice = getChoice("What race would you like to play?", races, s);
    switch (choice) {
    case 1:
      c.setRace(new Elf(r));
      break;
    case 2:
      c.setRace(new Goblin(r));
      break;
    case 3:
      c.setRace(new Tiefling(r));
      break;
    default:
      System.out.println("An error has occured.");
      break;
    }
    System.out.println();
    System.out.println("***-***-+-***-***-+-***-***-+-***-***-+-**-***-+-***-***-+-***-***");
    System.out.println();
    return c;

    /*
    try
    {
      // make an array with 2 slots string info
      String[] info = new String[3];
      String class1;
      String race;
      boolean validClass = false;
      boolean validRace = false;

      // prompt for character name
      System.out.println("Enter your character's name: ");
      info[0] = scan.nextLine();

      do
        {
          System.out.println("What class would you like to play?");
          class1 = scan.nextLine();
          if(class1.equalsIgnoreCase("barbarian") || class1.equalsIgnoreCase("wizard") || class1.equalsIgnoreCase("ranger"))
          {
            validClass = true;
            info[1] = class1;
          }
        }
        //if class1 is "barbarian" "wizard" or "ranger", exit loop
        while(validClass == false);

      // get race
      do
        {
          System.out.println("What race would you like to play?");
          race = scan.nextLine();
          if(race.equalsIgnoreCase("teifling") || race.equalsIgnoreCase("elf") || race.equalsIgnoreCase("goblin"))
          {
            validRace = true;
            info[2] = race;
          }
        }
        while(validRace == false);

      System.out.println("--------------- \n");
      return info;

    }
    catch(Exception e)
    {
      System.out.println("i WILL cry if this dons't work");
      return null;
    }

     */
  }

  public static void printBattleMap(Character p1, Character p2)
  {

    String[] a = {"      ","      ","      ","      ","      ","      ","      ","      ","      "};

    for(int i = 0; i < a.length; i++)
    {
      if(p1.getPosition() == i)
      {
        a[i] = "  P1  ";
      }
      else if(p2.getPosition() == i)
      {
        a[i] = "  P2  ";
      }
    }

    System.out.println();
    System.out.println("***-***-+-***-***-+-***-***-+-***-***-+-**-***-+-***-***-+-***-***");
    System.out.println();
    System.out.println();
    System.out.println("----------------------------------------------------------");
    System.out.println("|"+a[0]+"|"+a[1]+"|"+a[2]+"|"+a[3]+"|"+a[4]+"|"+a[5]+"|"+a[6]+"|"+a[7]+"|"+a[8]+"|");
    System.out.println("----------------------------------------------------------");
    System.out.println();

  }

  public static void battleRound(Scanner s, Character attacker, Character opponent) {

    //get actions
    String[] simpleActions = {"Move", "Flee", attacker.getRace().getTitle() + " Attack", attacker.getFighterType().getTitle() + " Attack"};
    String[] advancedActions = {"Move", "Flee", attacker.getRace().getTitle() + " Attack", attacker.getFighterType().getTitle() + " Attack", "Advanced" + attacker.getRace().getTitle() + "Attack", "Advanced " + attacker.getFighterType().getTitle() + " Attack"};
    String[] actions;

    if (attacker.getIsAdvanced() == false) {
      actions = simpleActions;
    }
    else {
      actions = advancedActions;
    }

    //decide action
    int choice = getChoice(attacker.getName() + ", what would you like to do?", actions, s);
    System.out.println();

    switch (choice) {
    case 1:
      String[] options = {"Left", "Right"};
      int directionChoice = getChoice("Where do you want to go?", options, s);
      char direction = directionChoice == 1 ? '-' : '+';
      attacker.move(direction);
      break;
    case 2:
      attacker.getRace().setCurrentHp(0);
      break;
    case 3:
      attacker.getRace().attack1(attacker, opponent);
      break;
    case 4:
      attacker.getFighterType().attack1(attacker, opponent);
      break;
    case 5:
      attacker.getRace().attack2(attacker, opponent);
      break;
    case 6:
      attacker.getFighterType().attack2(attacker, opponent);
    default:
      System.out.println("An error has occured.");
      break;
    }

  }

  public static void doBattle(ArrayList<Character> options, int id1, int id2, Scanner s) {

    Character p1 = options.get(id1);
    Character p2 = options.get(id2);

    p1.setPosition(2);
    p2.setPosition(6);
    p1.getRace().setCurrentHp(p1.getRace().getMaxHp());
    p2.getRace().setCurrentHp(p2.getRace().getMaxHp());

    int i = 1;

    do {

      printBattleMap(p1, p2);

      System.out.println(p1.getName() + "'s HP: " + p1.getRace().getCurrentHp() + "                            " + p2.getName() + "'s HP: " + p2.getRace().getCurrentHp());
      System.out.println();
      System.out.println();

      if (i % 2 == 1) {
        battleRound(s, p1, p2);
      }
      else {
        battleRound(s, p2, p1);
      }

      i++;

    } while(p1.getRace().getCurrentHp() > 0 && p2.getRace().getCurrentHp() > 0);

    if (p1.getRace().getCurrentHp() > 0) {
      options.get(id1).win();
    }
    else {
      options.get(id2).win();
    }
  }

  public static int getChoice(String msg, String[] choices, Scanner s) {
    System.out.println(msg);
    for (int i = 0; i < choices.length; i++) {
      System.out.println((i + 1) + ": " + choices[i]);
    }
    boolean pass = false;
    int c = 0;
    int i = 0;
    while (pass == false) {
      try {
        if (i > 1) {
          System.out.println("Please enter a number");
        }
        String input = s.nextLine();
        c = Integer.parseInt(input);
        pass = true;
      }
      catch(Exception e) {
        pass = false;
        i++;
      }
    }

    while (c < 1 || c > choices.length) {
      System.out.println("Please enter a number between 1 and " + choices.length + ".");
    }
    return c;
  }

  public static int getDistance(int p1, int p2) {
    int distance;
    if (p1 > p2) {
      distance = p1 - p2 - 1;
    }
    else {
      distance = p2 - p1 - 1;
    }
    return distance;
  }

  public static void linebreak() {
    System.out.println("");
    System.out.println("    *    *    *    *    *    *    *    *    *    *    *    *    *    ");
    System.out.println(" -+   +-   -+   +-   -+   +-   -+   +-   -+   +-   -+   +-   -+   +- ");
    System.out.println("    *    *    *    *    *    *    *    *    *    *    *    *    *    ");
    System.out.println("");
  }

  // -x  - x -  - x - x - x -  - x - x -


  public static void main(String[] args) throws IOException {

  welcomeScreen();

    loadScreen();

    Random r = new Random();

    try {
      Scanner s = new Scanner(System.in);

      // CREATE PLAYERS
      ArrayList<Character> characterSelection = new ArrayList<Character>();
      for (int i = 0; i < 2; i++) {
        System.out.println("Player " + (i + 1) + ":");
        characterSelection.add(characterSetup(s, r));
        s.nextLine(); //clear newline
      }

      doBattle(characterSelection, 0, 1, s);

      boolean keepPlaying = true;
      do {
        linebreak();
        String[] options = {"Battle!", "Create a new character", "View characters' stats", "Quit"};
        int choice = getChoice("What's the next step in your adventure?", options, s);
        System.out.println();

        switch (choice) {
        case 1:
          System.out.println("Who are the fighters?");
          String[] characterOptions = new String[characterSelection.size()];
          for (int i = 0; i < characterSelection.size(); i++) {
            characterOptions[i] = characterSelection.get(i).getName();
          }
          int p1 = getChoice("Player 1:", characterOptions, s);
          int p2 = getChoice("Player 2:", characterOptions, s);
          System.out.println("Interesting choices. Good luck...");
          doBattle(characterSelection, p1 - 1, p2 - 1, s);
          break;
        case 2:
          characterSelection.add(characterSetup(s, r));
          break;
        case 3:
          for (int j = 0; j < characterSelection.size(); j++) {
            characterSelection.get(j).printInfo();
            System.out.println();
          }
          break;
        case 4:
          keepPlaying = false;
          System.out.println("You've had a good run traveler. Rest well.");
          break;
        default:
          System.out.println("An error has occured.");
          break;
        }
      }while (keepPlaying == true);

    }
    catch(Exception e) {
      System.out.println("An error has occured in the driver.");
    }
  }
}