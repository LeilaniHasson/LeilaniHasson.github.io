import java.util.Random;

public class Goblin extends Race {

  Random r = new Random();

  // constructor
  public Goblin(Random r) {
    //hp 8-10, constitution 8-10
    super(r.nextInt(2) + 8, 10 - r.nextInt(2));
    this.setTitle("Goblin");
  }

  //methods
  public void attack1(Character attacker, Character opponent) {
    System.out.println("You slam your greathammer towards " + opponent.getName());

    // roll 1-20 + strength bonus
    int attack = (r.nextInt(19) + 1) + (attacker.getFighterType().getStrength());
      //maxDamage: 5, attack, random, isMelee: true, distance
    opponent.beAttacked(5, attack, r, true, Main.getDistance(attacker.getPosition(), opponent.getPosition()));

  }

  public void attack2(Character attacker, Character opponent) {
    System.out.println("You sneak through the dark, suprising " + opponent.getName() + " with your dagger");

    // roll 1-20 + strength bonus
    int attack = (r.nextInt(19) + 1) + (attacker.getFighterType().getStrength());
      //maxDamage: 9, attack, random, isMelee: true, distance
    opponent.beAttacked(9, attack, r, true, Main.getDistance(attacker.getPosition(), opponent.getPosition()));
  }
}