import java.util.Random;

public class Wizard extends FighterType {

  Random r = new Random();

  // constructor
  public Wizard(Random r) {
    // wisdom 10-12 strength 6-8
    super(r.nextInt(2) + 10, 8 - r.nextInt(2));
    this.setTitle("Wizard");
  }

  // methods
  public void attack1(Character attacker, Character opponent) {
    System.out.println("You flip through your spellbook and hurl a spell towards " + opponent.getName());

    // roll 1-15 + wisdom bonus
    int attack = (r.nextInt(14) + 1) + (attacker.getFighterType().getWisdom());
    // maxDamage: 4, attack, random, isMelee: false, distance
    opponent.beAttacked(4, attack, r, false, Main.getDistance(attacker.getPosition(), opponent.getPosition()));

  }

  public void attack2(Character attacker, Character opponent) {
    System.out.println("You bend the fabric of the universe to harm " + opponent.getName());

    // roll 1-15 + wisdom bonus
    int attack = (r.nextInt(14) + 1) + (attacker.getFighterType().getWisdom());
    // maxDamage: 8, attack, random, isMelee: false, distance
    opponent.beAttacked(8, attack, r, false, Main.getDistance(attacker.getPosition(), opponent.getPosition()));
  }
}