// superclass
import java.util.Random;

public class Character {

  // data members
  private String name; 
  private int strength, constitution, wisdom, ac, position;
  private FighterType fighterType;
  private Race race;
  private boolean isAdvanced;
  private int wins;


  // constructor

  public Character(String n){
    // set default stats
    ac = 14;
    isAdvanced = false;
    wins = 0;
    name = n;
  }


  // getters

  public String getName(){
    return name;
  }

  public int getStrength(){
    return strength;
  }

  public int getConstitution(){
    return constitution;
  }

  public int getWisdom(){
    return wisdom;
  }

  public int getAc(){
    return ac;
  }

  public int getPosition(){
    return position;
  }

  public FighterType getFighterType() {
    return fighterType;
  }

  public Race getRace() {
    return race;
  }

  public boolean getIsAdvanced() {
    return isAdvanced;
  }

  public int getWins() {
    return wins;
  }




  // setters
  public void setName(String newName){
    name = newName;
  }

  public void setStrength(int newStrength){
    strength = newStrength;
  }

  public void setConstitution(int newConstitution){
    constitution = newConstitution;
  }

  public void setWisdom(int newWisdom){
    wisdom = newWisdom;
  }

  public void setAc(int newAc){
    ac = newAc;
  }

  public void setPosition(int newPosition){
    position = newPosition;  
  }

  public void setFighterType(FighterType newFighterType) {
    fighterType = newFighterType;
  }

  public void setRace(Race newRace) {
    race = newRace;
  }

  public void setIsAdvanced(boolean i) {
    isAdvanced = i;
  }

  public void setWins(int w) {
    wins = w;
  }

  // other methods


  public void move(char direction)
  {
    if(direction == '+' && position < 8 )
    {
      setPosition(position + 1);
    }
    else if(direction == '-' && position > 0)
    {
      setPosition(position - 1);
    }
    else
    {
      System.out.println("Oops! " + name + " hit a wall");
    }

  }

  public void beAttacked(int maxDamage, int attack, Random r, boolean isMelee, int distance) {
    if (isMelee && distance > 0) {
      System.out.println("...but they're too far away.");
    }
    else if (isMelee == false && attack + distance > ac) {
      int damage = r.nextInt(maxDamage - 1) + 1;
      System.out.println("You hit them for " + damage + " damage!");
      this.getRace().setCurrentHp(this.getRace().getCurrentHp() - damage);
    }
    else if (isMelee == true && attack > ac) {
      int damage = r.nextInt(maxDamage - 1) + 1;
      System.out.println("You slash them for " + damage + " damage!");
      this.getRace().setCurrentHp(this.getRace().getCurrentHp() - damage);
    }
    else {
      System.out.println("They dodge out of the way.");
    }
  }

  public void win() {
    wins++;
    isAdvanced = true;
    System.out.println("Congragulations, " + name + ", you won!");
    if (wins == 1) {
      System.out.println("You've won your first battle, and been initated as a true adventurer. You are now Advanced.");
      isAdvanced = true;
      levelUp();
    }
    else {
      System.out.println("You've now won " + wins + " battles--a fearsome " + fighterType.getTitle() + " indeed.");
    }
  }

  public void printInfo() {
    System.out.println("Name: " + name);
    System.out.println("HP: " + this.getRace().getMaxHp());
    System.out.println("Armor Class: " + ac);
    System.out.println("Strength: " + this.getFighterType().getStrength());
    System.out.println("Wisdom: " + this.getFighterType().getWisdom());
    System.out.println("Constitution: " + this.getRace().getConstitution());
    System.out.println("Wins: " + wins);
    if (isAdvanced) {System.out.println(" ~ Advanced ~ ");};
    System.out.println();
  }

  public void levelUp() {
    this.getRace().setMaxHp(this.getRace().getMaxHp() + 5);
    ac += 3;
  }

  /*


    Random rand = new Random();
    // have base starts be set at a random number from 1-10
    strength = rand.nextInt(10)+1;
    constitution = rand.nextInt(10)+1;
    wisdom = rand.nextInt(10)+1;

    // class bonuses
    if(fighterType == Ranger)
    {
      classStrengthBonous();
    }
    else if(fighterType == Wizard)
    {
      classWisdomBonous();
    }
    else
    {
      classConstitutionBonous();
    }
  }


  // ---- IMPLEMENT FIGHTER-TYPE INTERFACE METHODS ----
  // WIZARD
  public int castSpell()
  {}
  public void classWisdomBonous()
  {
    try{
      Random r = new Random();
      int CWB = r.nextInt(4);
      setWisdom(getWisdom() + CWB);
    }
    catch(Exception e){
    }
  }

  // RANGER
  public int shootArrow()
  {}
  public void classStrengthBonous()
  {
    try{
      Random r = new Random();
      int CSB = r.nextInt(4);
      setStrength(getStrength() + CSB);
    }
    catch(Exception e){
    }
  }

  // PALADIN
  if(fighterType == Paladin)
{

}
  public int useSword()
  {}

  public void classConstitutionBonous()
  {
    try{
      Random r = new Random();
      int CCB = r.nextInt(4);
      setConstitution(getConstitution() + CCB);
    }
    catch(Exception e){
    }
  }

   */

}