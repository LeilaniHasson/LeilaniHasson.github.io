public interface hasAttacks {
  public void attack1(Character p1, Character p2);
  public void attack2(Character p1, Character p2);
}