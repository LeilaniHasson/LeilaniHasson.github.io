import java.util.Random;

public class Ranger extends FighterType {

  Random r = new Random();

  // constructor
  public Ranger(Random r) {
    //wisdom 8-10 strength 8-10
    super(r.nextInt(2) + 8, 10 - r.nextInt(2));
    this.setTitle("Ranger");
  }

  //methods
  public void attack1(Character attacker, Character opponent) {
    System.out.println("You nock an arrow and fire at " + opponent.getName());

    // roll 1-15 + constitution bonus
    int attack = (r.nextInt(14) + 1) + (attacker.getRace().getConstitution());
      //maxDamage: 4, attack, random, isMelee: false, distance
    opponent.beAttacked(4, attack, r, false, Main.getDistance(attacker.getPosition(), opponent.getPosition()));

  }

  public void attack2(Character attacker, Character opponent) {
    System.out.println("A vine grows from your hand and lashes out towards " + opponent.getName());

    // roll 1-20 + constitution bonus
    int attack = (r.nextInt(19) + 1) + (attacker.getRace().getConstitution());
      //maxDamage: 9, attack, random, isMelee: true, distance
    opponent.beAttacked(9, attack, r, true, Main.getDistance(attacker.getPosition(), opponent.getPosition()));
  }
}