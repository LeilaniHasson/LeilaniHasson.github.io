public class Settings {
    public static int height = 10; // Assuming height is 10, you can replace it with the actual value
    public static int width = 20;  // Assuming width is 20, you can replace it with the actual value
}