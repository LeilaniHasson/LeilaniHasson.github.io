import java.util.Random;

public class Paladin extends FighterType {

  Random r = new Random();

  // constructor
  public Paladin(Random r) {
    //wisdom 6-8 strength 10-12
    super(r.nextInt(2) + 6, 12 - r.nextInt(2));
    this.setTitle("Paladin");
  }

  //methods
  public void attack1(Character attacker, Character opponent) {
    System.out.println("You slash out with your sword against " + opponent.getName());

    // roll 1-20 + strength bonus
    int attack = (r.nextInt(19) + 1) + (attacker.getFighterType().getStrength());
      //maxDamage: 5, attack, random, isMelee: true, distance
    opponent.beAttacked(5, attack, r, true, Main.getDistance(attacker.getPosition(), opponent.getPosition()));

  }

  public void attack2(Character attacker, Character opponent) {
    System.out.println("You channel a powerful smite into your sword and stab towards " + opponent.getName());

    // roll 1-20 + strength bonus
    int attack = (r.nextInt(19) + 1) + (attacker.getFighterType().getStrength());
      //maxDamage: 9, attack, random, isMelee: true, distance
    opponent.beAttacked(9, attack, r, true, Main.getDistance(attacker.getPosition(), opponent.getPosition()));
  }
}