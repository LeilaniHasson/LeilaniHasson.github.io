public class WildTile extends Tile {

  //constructor
  public WildTile(char l, int v) {
    super(l, v);
  }

}